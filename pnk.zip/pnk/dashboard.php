<?php

session_start();

if(isset($_SESSION['usuario']))
{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link href="css/login.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</head>
<body>
   <div id="sesion"> 
        <div class="card">
            <div class="card-header">Sesión Iniciada por:</div>
            <div class="card-body"><?php echo $_SESSION['usuario'];?></div>
            <div class="card-footer"><a href="cerrar.php">Cerrar Sesión</a></div>
        </div>
   </div>
    <hr>

    <div id="caja"> 
        <div class="card">
            <div class="card-header">CRUD Usuarios</div>
            <div class="card-body"><a href="registro_usuario.php"><img src="img/ico_usu.png"></a></div>
        </div>
   </div>

</body>
</html>
<?php
}else{
    header("Location:error.html");
}
?>