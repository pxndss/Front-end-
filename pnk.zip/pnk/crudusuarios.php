<?php

include("setup/config.php");


//////// TRABAJAR CON EL INPUT TYPE FILES

//echo $_FILES['frm_foto']['name']."<br>";
//echo $_FILES['frm_foto']['type']."<br>";
//echo $_FILES['frm_foto']['size']."<br>";
//echo $_FILES['frm_foto']['tmp_name']."<br>";






if(isset($_GET['idusu']))
{
    $sql="DELETE FROM usuarios WHERE id = ".$_GET['idusu'];
    mysqli_query(conectar(),$sql);
    header("Location:registro_usuario.php");

    //HABILITAR SWITCH ALERT
}


switch($_POST['opoculto']){
    case "Ingresar": ingresar();
        break;
    case "Modificar":modificar();
        break;
    case "Eliminar":eliminar();
        break;
    case "Cancelar":cancelar();
        break;
}

function ingresar()
{
    $sql="INSERT INTO usuarios (rut, nombres, ap_paterno, ap_materno, usuario, clave, estado, foto) VALUES ('".$_POST['rut']."', '".$_POST['nombre']."', '".$_POST['appaterno']."', '".$_POST['apmaterno']."', '".$_POST['usuario']."',estado=".$_POST['estado'].", '".password_hash($_POST['clave'], PASSWORD_BCRYPT)."', '".$_FILES['frm_foto']['name']."')";
    mysqli_query(conectar(),$sql);
    move_uploaded_file($_FILES['frm_foto']['tmp_name'], "img/usuarios/".$_FILES['frm_foto']['name']);
    header("Location:registro_usuario.php");
}

function modificar()
{
    if($_FILES['frm_foto']['name']!='')
    {
        $sql="UPDATE usuarios SET rut='".$_POST['rut']."', nombres = '".$_POST['nombre']."', ap_paterno = '".$_POST['appaterno']."', ap_materno = '".$_POST['apmaterno']."', usuario = '".$_POST['usuario']."', estado=".$_POST['estado'].", foto='".$_FILES['frm_foto']['name']."' WHERE id =".$_POST['idoculto'];
        move_uploaded_file($_FILES['frm_foto']['tmp_name'], "img/usuarios/".$_FILES['frm_foto']['name']);
    }else{
        $sql="UPDATE usuarios SET rut='".$_POST['rut']."', nombres = '".$_POST['nombre']."', ap_paterno = '".$_POST['appaterno']."', ap_materno = '".$_POST['apmaterno']."', usuario = '".$_POST['usuario']."', estado=".$_POST['estado']." WHERE id =".$_POST['idoculto'];
    }
    
    mysqli_query(conectar(),$sql);
    header("Location:registro_usuario.php");
}

function eliminar()
{
    $sql="DELETE FROM usuarios WHERE id = ".$_POST['idoculto'];
    mysqli_query(conectar(),$sql);
    header("Location:registro_usuario.php");
    //HABILITAR SWITCH ALERT
}


function cancelar()
{
    header("Location:registro_usuario.php");
}


?>