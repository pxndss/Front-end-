<?php

include("setup/config.php");

$sql="select * from usuarios where usuario='".$_POST['usuario']."' and clave='".md5($_POST['clave'])."' and estado=1";
$result=mysqli_query(conectar(),$sql); //Ejecutamos la Query
$datos=mysqli_fetch_array($result);//Traemos el resultado de la query
$contador=mysqli_num_rows($result);// contamos cuantos registros hay del resultado

if($contador!=0)
{
    session_start(); //inicializar sessión
    $_SESSION['usuario']=$datos['nombres'];// creamos una variable sessión y dejamos el dato que viene de la base de datos
    header("Location:dashboard.php");
}else{
    header("Location:login.html");
}




?>