<?php

function conectar()
{
    $con=mysqli_connect("localhost","root","","pnk");
    return $con;
}

function contarusu()
{
    $sql="select * from usuarios";
    $result=mysqli_query(conectar(),$sql);
    $contar=mysqli_num_rows($result);

    return $contar;
}

?>