<?php

include("setup/config.php"); //LLamamos al Archivo principal de config

if(isset($_GET['idusu']))
{ 
    $sql="select * from usuarios where id=".$_GET['idusu'];
    $result=mysqli_query(conectar(),$sql);
    $datosusu=mysqli_fetch_array($result);
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fomulrario Registro de Usuario</title>
    <link href="css/fomrularios.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="js/jquery-3.7.1.min.js"></script>
    <script src="js/jquery.Rut.js"></script>

<script>
    function enviar(op)
    {
        document.formulario.opoculto.value=op;
        document.formulario.submit();
    }

    $(document).ready(function() {
        $('#rut').Rut({
                on_error: function(){ alert('Rut incorrecto'); }
        });
    });

</script>

</head>
<body>
    
    <div id="formulario">
        <div class="card">
            <div class="card-header">CRUD USUARIOS</div>
            <div class="card-body">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-3">

                    <?php

                        if(isset($_GET['idusu']))
                        {
                            if($datosusu['foto']!='')
                            {
                        ?>
                            <img src="img/usuarios/<?php echo $datosusu['foto'];?>" width="150px">
                        <?php
                            }else{ ?>
                                <img src="img/usuarios/comodin.png" width="150px">
                            <?php
                            }
                        }else{
                        ?>
                            <img src="img/usuarios/comodin.png" width="150px">
                        <?php
                        }
                    ?>
                    </div>
                    <div class="col-sm-9">
                        <form action="crudusuarios.php" name="formulario" method="post" enctype="multipart/form-data">
                            <div id="campos">
                                <div class="row">
                                    <div class="col-sm"><label for="rut" class="form-label">Rut</label></div>
                                    <div class="col-sm"><input type="text" class="form-control" id="rut" name="rut" value="<?php if(isset($_GET['idusu'])){ echo $datosusu['rut'];}?>"></div>
                                    <div class="col-sm"><label for="nombre" class="form-label">Nombres</label></div>
                                    <div class="col-sm"><input type="text" class="form-control" id="nombre" name="nombre" value="<?php if(isset($_GET['idusu'])){ echo $datosusu['nombres'];}?>"></div>
                                </div>
                                <div class="row">
                                    <div class="col-sm">Apellido Pat.</div>
                                    <div class="col-sm"><input type="text" class="form-control" id="appaterno" name="appaterno" value="<?php if(isset($_GET['idusu'])){ echo $datosusu['ap_paterno'];}?>"></div>
                                    <div class="col-sm">Apellido Mat</div>
                                    <div class="col-sm"><input type="text" class="form-control" id="apmaterno" name="apmaterno" value="<?php if(isset($_GET['idusu'])){ echo $datosusu['ap_materno'];}?>"></div>
                                </div>
                                <div class="row">
                                    <div class="col-sm">Usuario</div>
                                    <div class="col-sm"><input type="email" class="form-control" id="usuario" name="usuario" value="<?php if(isset($_GET['idusu'])){ echo $datosusu['usuario'];}?>"></div>
                                <?php
                                if(!isset($_GET['idusu'])){
                                ?>
                                    <div class="col-sm">Clave</div>
                                    <div class="col-sm"><input type="password" class="form-control" id="clave" name="clave"></div>
                                <?php
                                }else{
                                    ?>
                                        <div class="col-sm"></div>
                                        <div class="col-sm"></div>
                                    <?php
                                }
                                ?>
                                    
                                </div>
                                <div class="row">
                                    <div class="col-sm">Estado</div>
                                    <div class="col-sm">
                                        <select class="form-select" name="estado">
                                            <option value="3" selected>Seleccionar</option>
                                            <option value="1" <?php if(isset($_GET['idusu'])){ if($datosusu['estado']==1){?> selected <?php }} ?>>Activo</option>
                                            <option value="0" <?php if(isset($_GET['idusu'])){ if($datosusu['estado']==0){?> selected <?php }} ?>>Inactivo</option>
                                        </select>
                                    </div>
                                    <div class="col-sm">Subir Forografía</div>
                                    <div class="col-sm"><input type="file" name="frm_foto"></div>
                                </div>

                                
                            </div>
                            <br><center>

                            <?php

                            if(!isset($_GET['idusu']))
                            {
                                ?>
                                <button type="button" onclick="enviar(this.value);" class="btn btn-primary" value="Ingresar">INGRESAR</button>
                                <?php
                            }else{
            ?>
                                <button type="button" onclick="enviar(this.value);" class="btn btn-success" value="Modificar">MODIFICAR</button>
                                <button type="button" onclick="enviar(this.value);" class="btn btn-danger" value="Eliminar">ELIMINAR</button>
            <?php
                            }
                            ?>
                            <button type="button" onclick="enviar(this.value);" class="btn btn-secondary" value="Cancelar">CANCELAR</button></center>
                            <input type="hidden" name="opoculto">
                            <input type="hidden" name="idoculto" value="<?php if(isset($_GET['idusu'])){ echo $_GET['idusu'];}?>">
                        </form>
                    </div>
                </div>
            </div>
              
            </div>
          </div>
    </div>
    <div id="mostrarusuarios">
        <div class="card">
            <div class="card-header">Listado de los Usuarios (<b>Total de Usuario (<?php echo contarusu();?>)</b>)</div>
            <div class="card-body">
                <table class="table table-hover">
                    <thead>
                    <tr>
                        <th>N°</th>
                        <th>Foto</th>
                        <th>Rut</th>
                        <th>Nombres</th>
                        <th>Apellidos</th>
                        <th>Usuario/correo</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                        $num=1;
                        $sql="select * from usuarios";
                        $result=mysqli_query(conectar(),$sql);
                        while($datos=mysqli_fetch_array($result))
                        {
                    ?>
                        <tr>
                            <td><?php echo $num;?></td>
                            <td>
                                    <?php 
                                           if($datos['foto']=='')
                                           { ?>
                                                <img src="img/usuarios/comodin.png" width="32px">
                                            <?php 
                                           }else{
                                            ?>
                                                <img src="img/usuarios/<?php echo $datos['foto'];?>" width="32px">
                                            <?php
                                           }
                                    ?>
                            </td>
                            <td><?php echo $datos['rut'];?></td>
                            <td><?php echo $datos['nombres'];?></td>
                            <td><?php echo $datos['ap_paterno']." ".$datos['ap_materno'];?></td>
                            <td><?php echo $datos['usuario'];?></td>
                            <td>
                                <?php
                                if($datos['estado']==1)
                                {
                                ?>
                                    <img src="img/activo.png" width="16px">
                                <?php
                                }else{
                                ?>
                                    <img src="img/inactivo.png" width="16px">
                                <?php
                                }
                                ?>
                            </td>
                            <td>
                                <a href="registro_usuario.php?idusu=<?php echo $datos['id'];?>"><img src="img/update.png" width="24px"></a>
                                |
                                <a href="crudusuarios.php?idusu=<?php echo $datos['id'];?>"><img src="img/delete.png" width="24px"></a>
                            </td>
                        </tr>
                    <?php
                            $num++;
                        }
                    ?>
                    </tbody>
                </table>
            </div>
    </div>

</body>
</html>